#include "Mundo.h"
#include "ETSIDI.h"
#include "Tablero.h"


class Coordinador
{
protected: 
	Mundo mundo; 
	Tablero tablero; 
	enum Estado{INICIO, JUEGO, FIN, PAUSA};
	Estado estado; 

public: 
	Coordinador(void); 
	virtual ~Coordinador(void);

	void tecla(unsigned char key); 
	void mueve(); 
	void dibuja(); 	
};

