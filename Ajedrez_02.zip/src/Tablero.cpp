#include "Tablero.h"

void Tablero::pintartablero() 
{
	gluLookAt(0, 7.5, 30, // posici�n del ojo
		0.0, 7.5, 0.0,	// hacia que punto mira
		0.0, 0.1, 0.0); // definimos hacia arriba (eje Y)

	for (i = 0;i < 8;i++) {
		for (j = 0;j < 8;j++) {
			int suma = i + j;
			if ((suma % 2) !=0) {
				casilla[i][j].pintarnegra(i,j);
			}

			if ((suma % 2) == 0) {
				casilla[i][j].pintarblanca(i,j);
			}

		}
	}
}
