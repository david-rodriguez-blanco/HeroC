#pragma once
class Casilla
{
private:
	int x, y;

public: 
	void pintarnegra(int, int); // Funci�n para pintar la casilla negra
	void pintarblanca(int, int); // Funci�n para pintar la casilla blanca
};



