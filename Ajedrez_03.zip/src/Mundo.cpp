#include "Mundo.h"
#include "freeglut.h"
#include <math.h>
#include "Tablero.h"

void Mundo::rotarOjo()
{
	float dist=sqrt(x_ojo*x_ojo+z_ojo*z_ojo);
	float ang=atan2(z_ojo,x_ojo);
	ang+=0.05f;
	x_ojo=dist*cos(ang);
	z_ojo=dist*sin(ang);
}
void Mundo::dibuja()
{
	//A continuaci�n se pone el c�digo de dibujo

	tablero.pintartablero(); // Dibujo del tablero
}

void Mundo::mueve()
{

}

void Mundo::inicializa()
{
	x_ojo=4;
	y_ojo=4;
	z_ojo=12;	
}

void Mundo::tecla(unsigned char key)
{

}
