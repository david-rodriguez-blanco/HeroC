#pragma once
class Pieza
{
protected:

};

