#pragma once
#include "Casilla.h"
#include "freeglut.h"


class Tablero
{
private:
	Casilla casilla[8][8];
	int i, j;
	
public: 
	void pintartablero(); // Funci�n para pintar el tablero
};

