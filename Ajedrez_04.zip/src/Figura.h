#ifndef FIGURA_H
#define FIGURA_H
//Es la clase base de las piezas
#include "ETSIDI.h"
#include "freeglut.h"
#include <string>
#include <iostream>
using namespace std;
using namespace ETSIDI;

class Figura
{
public:
	enum COLOR { NS = -1, BLANCO, NEGRO };//color de la pieza
	enum TIPO{NF = -1, PEON, CABALLO};
	Figura();
	Figura(TIPO t, COLOR c, int x, int y);

	virtual void print();
	virtual void dibujar();
protected:
	TIPO tipo;
	COLOR Color;
	int pos_x;
	int pos_y;
};

#endif