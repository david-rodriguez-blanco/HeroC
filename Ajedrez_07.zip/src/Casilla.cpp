#include "Casilla.h"

Casilla::~Casilla()
{
}

void Casilla::destruirContenido()
{
	for (int i = 0;i < tam;i++)
	{
		figu[i] = 0;
	}
	tam = 0;
}
/////////////////////////////////////////
Figura* Casilla::seleccionar(int x, int y)
{
	bool var;
	Figura* aux=0;
	for (int i = 0;i < tam;i++)
	{
		var = figu[i]->seleccionar(x, y);
		if (var == true)
			aux = figu[i];
	}
	return aux;
}

bool Casilla::mover(int x, int y)
{
	bool retorno=false;
	Figura* aux = 0;
	aux = seleccionar(x, y);
	if (aux == 0)
		return retorno;
	retorno = aux->mover(x, y);
	return retorno;
}
/////////////////////////////////////////


bool Casilla::agregar(Figura* f)//para agregar figuras
{
	if (tam < MAX)
	{
		figu[tam++] = f;
		return true;
	}
	else return false;
}

void Casilla::dibujar()
{
	for (int i = 0;i < tam;i++)
		figu[i]->dibujar();
}
