#ifndef CASILLA_H
#define CASILLA_H
//lista para gestionar las figuras
#include "Figura.h"
#define MAX 100

class Casilla
{
private:
	int tam;
	Figura* figu[MAX];
public:
	Casilla() :tam(0)
	{
		for (int i = 0;i < MAX;i++)
			figu[i] = NULL;
	}
	virtual ~Casilla();
	bool agregar(Figura* f);
	void dibujar();
	void destruirContenido();
	Figura* seleccionar(int x, int y);//new
	bool mover(int x,int y);//new
};

#endif



