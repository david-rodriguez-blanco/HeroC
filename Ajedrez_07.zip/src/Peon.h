#ifndef PEON_H
#define PEON_H
#include "Figura.h"
class Peon:public Figura  
{
private:
	SpriteSequence sprite_peon_blanco{ "imagenes/peon_blanco.png", 1 };
	SpriteSequence sprite_peon_negro{ "imagenes/peon_negro.png", 1 };
public:
	Peon();
	Peon(Figura::COLOR c, int x = -1, int y = -1);
	virtual ~Peon();
	void print();
	void dibujar();
	bool mover(int x, int y);//new
	bool seleccionar(int x, int y);
};

#endif