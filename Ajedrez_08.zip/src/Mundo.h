#pragma once
//#ifndef MUNDO_H
//#define MUNDO_H
#include "Tablero.h"
#include "Casilla.h"
#include "Peon.h"

class Mundo
{
protected: 
	int mouse_x, mouse_y;
	Tablero tablero;
	//Figura peon_b;//test
	Casilla piezas;
	//Peon p1;
	

public://Peon p2;
	void raton(int button,int state, int _x, int _y);
	~Mundo();
	void tecla(unsigned char key);
	void inicializa();
	void rotarOjo();
	void mueve();
	void dibuja(int color_tablero);

	float x_ojo;
	float y_ojo;
	float z_ojo;
};

//#endif
