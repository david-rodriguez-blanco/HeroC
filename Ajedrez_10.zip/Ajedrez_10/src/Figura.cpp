#include "Figura.h"


Figura::Figura()
{
	tipo = NF;
	Color = NS;
	pos_x = -1;
	pos_y = -1;
}

Figura::Figura(TIPO t, COLOR c, int x, int y)
{
	tipo = t;
	Color = c;
	pos_x = x;
	pos_y = y;
}

bool Figura::estado()
{
	return seleccionado;
}

void Figura::print()
{
}

void Figura::dibujar()
{
}

bool Figura::mover(int x, int y)
{
	return false;
}

bool Figura::seleccionar(int x, int y)
{
	return false;
}



