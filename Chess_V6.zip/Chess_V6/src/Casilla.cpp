#include "Casilla.h"

Casilla::~Casilla()
{
}

void Casilla::destruirContenido()
{
	for (int i = 0;i < tam;i++)
	{
		figu[i] = 0;
	}
	tam = 0;
}

bool Casilla::agregar(Figura* f)//para agregar figuras
{
	if (tam < MAX)
	{
		figu[tam++] = f;
		return true;
	}
	else return false;
}

void Casilla::dibujar()
{
	for (int i = 0;i < tam;i++)
		figu[i]->dibujar();
}
