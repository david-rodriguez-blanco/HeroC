#include "Mundo.h"
#include "freeglut.h"
#include <math.h>

void Mundo::rotarOjo()
{
	float dist=sqrt(x_ojo*x_ojo+z_ojo*z_ojo);
	float ang=atan2(z_ojo,x_ojo);
	ang+=0.05f;
	x_ojo=dist*cos(ang);
	z_ojo=dist*sin(ang);
}
void Mundo::dibuja()
{
	gluLookAt(x_ojo, y_ojo, z_ojo,  // posicion del ojo
			4.0, 4.0, 0.0,      // hacia que punto mira  (0,0,0) 
			0.0, 1.0, 0.0);      // definimos hacia arriba (eje Y)    

	//aqui es donde hay que poner el codigo de dibujo
	//dibujo del suelo
	tablero.pintartablero();
	piezas.dibujar();
	//c.dibujar();
	//p1.dibujar();
	
	
}

void Mundo::mueve()
{

}

void Mundo::inicializa()
{
	x_ojo=4;
	y_ojo=4;
	z_ojo=12;
	for (int i = 0;i<8;i++)
	{
		Peon* aux1 = new Peon(Figura::BLANCO, i, 1);
		piezas.agregar(aux1);
		Peon* aux2 = new Peon(Figura::NEGRO, i, 6);
		piezas.agregar(aux2);
	}
	
	//p1.inicializar(Figura::BLANCO, 0, 1);//para posicionar un peon 
	
}

void Mundo::raton(int button,int state, int _x, int _y)
{
	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		cout << _x << "," << _y<< endl;
	
		for (int i = 0; i < 8; i++)
		{
			for (int j = 0; j < 8; j++)
			{
				if (_x < i && _x > i + 1 && _y < j && _y > j + 1)
				{

				}
			}
		}

	}
}

Mundo::~Mundo()
{
	piezas.destruirContenido();
}

void Mundo::tecla(unsigned char key)
{

}
