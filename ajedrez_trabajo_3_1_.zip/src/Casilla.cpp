/*#include "Casilla.h"

Casilla::~Casilla()
{
	for (int i = 0;i < tam;i++)
	{
		delete figu[i];
		figu[i] = NULL;
	}
}

bool Casilla::agregar(Figura* f)//para agregar figuras
{
	if (tam < maxi)
	{
		figu[tam++] = f;
		return true;
	}
	else return false;
}

void Casilla::dibujar()
{
	for (int i = 0;i < tam;i++)
		figu[i]->dibujar();
}
*/