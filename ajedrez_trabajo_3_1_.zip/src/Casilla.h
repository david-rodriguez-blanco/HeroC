/*#ifndef CASILLA_H
#define CASILLA_H
//lista para gestionar las figuras
#include "Figura.h"
#define MAX 32

class Casilla
{
private:
	int tam;
	const int maxi;
	Figura* figu[MAX];
public:
	Casilla() :tam(0), maxi(32) 
	{
		for (int i = 0;i < maxi;i++)
			figu[i] = NULL;
	}
	~Casilla();
	bool agregar(Figura* f);
	void dibujar();
	

};

#endif
*/


