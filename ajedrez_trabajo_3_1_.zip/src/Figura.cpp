#include "Figura.h"


Figura::Figura()
{
	tipo = "NULO";
	Color = NS;
	pos_x = -1;
	pos_y = -1;
}

Figura::Figura(string t, COLOR c, int x, int y)
{
	tipo = t;
	Color = c;
	pos_x = x;
	pos_y = y;
};
