#ifndef FIGURA_H
#define FIGURA_H
//Es la clase base de las piezas
#include "ETSIDI.h"
#include "Casilla.h"
#include "Tablero.h"
#include <string>
#include <iostream>
using namespace std;
using namespace ETSIDI;

class Figura
{
public:
	enum COLOR { NS = -1, BLANCO, NEGRO };//color de la pieza
	Figura();
	Figura(string t, COLOR c, int x, int y);
	virtual void inicializar() = 0;
	virtual void print() = 0;
	virtual void dibujar() = 0;
protected:
	string tipo;
	COLOR Color;
	int pos_x;
	int pos_y;
};

#endif