#include "Mundo.h"
#include "freeglut.h"
#include <math.h>
#include "Tablero.h"

void Mundo::rotarOjo()
{
	float dist=sqrt(x_ojo*x_ojo+z_ojo*z_ojo);
	float ang=atan2(z_ojo,x_ojo);
	ang+=0.05f;
	x_ojo=dist*cos(ang);
	z_ojo=dist*sin(ang);
}
void Mundo::dibuja()
{
	gluLookAt(x_ojo, y_ojo, z_ojo,  // posicion del ojo
			4.0, 4.0, 0.0,      // hacia que punto mira  (0,0,0) 
			0.0, 1.0, 0.0);      // definimos hacia arriba (eje Y)    

	//aqui es donde hay que poner el codigo de dibujo
	//dibujo del suelo
	tablero.pintartablero();
	//c.dibujar();
	//p1->dibujar();
	//p2->dibujar();
	p1.dibujar();
	p2.dibujar();
}

void Mundo::mueve()
{

}

void Mundo::inicializa()
{
	x_ojo=4;
	y_ojo=4;
	z_ojo=12;
	p1.inicializar("Peon blanco", Figura::BLANCO, 0, 1);//para posicionar un peon 
	p2.inicializar("Peon negro", Figura::NEGRO, 1, 6);
	
	//Intente hacerlo con herencia pero no lo consigo a�n, luego lo intentale
	//p1->inicializar("Peon blanco", Figura::BLANCO, 0, 1);
	//p2->inicializar("Peon negro", Figura::NEGRO, 0, 7);
	//c.agregar(new Peon("Peon blanco", Figura::BLANCO, 0, 1));
}

Mundo::~Mundo()
{
	//c.~Casilla();
}

void Mundo::tecla(unsigned char key)
{

}
