//#ifndef MUNDO_H
//#define MUNDO_H
#include "Tablero.h"
#include "Casilla.h"
#include "Peon.h"

class Mundo
{
public: 
	Tablero tablero;
	//Figura peon_b;//test
	//Casilla c;
	//Peon* p1;
	Peon p1;
	Peon p2;
	//Peon* p2;
	~Mundo();
	void tecla(unsigned char key);
	void inicializa();
	void rotarOjo();
	void mueve();
	void dibuja();

	float x_ojo;
	float y_ojo;
	float z_ojo;
};

//#endif
