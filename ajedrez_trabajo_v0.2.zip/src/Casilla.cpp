#include "Casilla.h"
#include "freeglut.h"

void Casilla::pintarnegra(int x,int y)
{ 

	glBegin(GL_POLYGON);
	glColor3ub(0, 0, 0);
	glVertex3d(x+1, y+1,0);
	glVertex3d(x+1, y, 0);
	glVertex3d(x,y, 0);
	glVertex3d(x,y+1, 0);
	glEnd();
	glEnable(GL_LIGHTING);
}

void Casilla::pintarblanca(int x,int y)
{
	glBegin(GL_POLYGON);
	glColor3ub(255, 255, 255);
	glVertex3d(x + 1, y + 1, 0);
	glVertex3d(x + 1, y, 0);
	glVertex3d(x, y, 0);
	glVertex3d(x, y + 1, 0);
	glEnd();
	glEnable(GL_LIGHTING);
}
