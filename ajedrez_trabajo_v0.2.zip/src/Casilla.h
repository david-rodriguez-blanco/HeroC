#pragma once
class Casilla
{
public:
	int x, y;

	void pintarnegra(int, int);
	void pintarblanca(int, int);
	};



