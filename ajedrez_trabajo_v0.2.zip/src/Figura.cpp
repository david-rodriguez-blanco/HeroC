#include "Figura.h"
//es un test para poner figura en el tablero
Figura::Figura()
{
	sprite.setCenter(1, 0);
	sprite.setSize(0.9, 0.9);//como z de la figura es 1, se establece una relaci�n entre casilla y figura de 1:0.9
}

void Figura::dibujar()
{
	glPushMatrix();
	glTranslatef(1.325, 1.25, 1);/*z = 1 para que la figura se ponga por encima del tablero,
			(1.325, 0.325, 1)  es la posici�n de primera casilla, +-0.925 es la el valor hay que sumar en x e/u y 
			para cambiar de casilla */
	glColor3f(1.0f, 0.0f, 0.0f);
	sprite.draw();
	glPopMatrix();
}
