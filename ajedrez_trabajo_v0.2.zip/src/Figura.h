#pragma once
#include "ETSIDI.h"
#include "Casilla.h"
#include "Tablero.h"
using namespace ETSIDI;

class Figura
{
	SpriteSequence sprite{ "imagenes/peon_blanco.png", 1 };/*es un test de figura peon blanco, 
									en versi�n final he pensado usar clase derivada para cada figura*/
public:
	Figura();
	void dibujar();
};