#include "Tablero.h"
#include "Casilla.h"
#include "Figura.h"

class Mundo
{
public: 
	Tablero tablero;
	Figura peon_b;//test

	void tecla(unsigned char key);
	void inicializa();
	void rotarOjo();
	void mueve();
	void dibuja();

	float x_ojo;
	float y_ojo;
	float z_ojo;
};
