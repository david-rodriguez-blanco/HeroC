#pragma once
#include "Casilla.h"


class Tablero
{
public:
	Casilla *casilla[8][8];
	int i, j;
	
	void pintartablero();

};

