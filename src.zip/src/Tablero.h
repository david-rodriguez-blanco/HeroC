#ifndef TABLERO_H
#define TABLERO_H
#include "Casilla.h"
#include "freeglut.h"


class Tablero
{
public:
	
	void pintartablero(int c);

};

#endif